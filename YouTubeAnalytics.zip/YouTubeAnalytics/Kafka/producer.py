import json
import csv
from kafka import KafkaProducer 
producer=KafkaProducer(bootstrap_servers="localhost:9092",
                    value_serializer=lambda x:x.encode("utf-8")
                       )
with open("video_events.csv","r")as files:
    reader=csv.DictReader(files) 
    for files in reader:
        print(files)
producer.send("youtube_events",value=json.dumps(files))
producer.flush()
producer.close()
    