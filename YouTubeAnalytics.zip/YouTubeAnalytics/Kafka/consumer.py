import json
from kafka import KafkaConsumer 
consumer=KafkaConsumer(
    "youtube_events",
    bootstrap_servers="localhost:9092",
    auto_offset_reset="earliest",
    enable_auto_commit=True,
    group_id="youtub99",
    value_deserializer=lambda x:x.decode("utf-8")
)
print("Waiting for messages")
for message in consumer:
    event=json.loads(message.value)
    print("event_id",event["event_id"])
    print("video_id",event["video_id"])
    print("event_type",event["event_type"])
    print("User-Country",event["user_country"])