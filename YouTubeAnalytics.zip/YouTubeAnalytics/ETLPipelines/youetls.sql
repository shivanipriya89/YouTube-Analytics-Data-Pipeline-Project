# Section-F
# End to End Pipeline
create database dbetls;
use dbetls;
create table staging_cleaned_channels(channel_id int primary key,channel_name varchar(100),
channel_category varchar(130),country varchar(250));
create table staging_cleaned_dates(date_key int primary key,full_date date,myyear year,
mymonth int,myday int,day_name varchar(100));
create table staging_cleaned_traffic(video_id int,traffic_date date,traffic_source varchar(100),
traffic_pct decimal(10,2),views_from_source bigint);
create table staging_cleaned_videos(event_id varchar(100),video_id bigint,channel_id bigint,
event_type varchar(100),user_country varchar(20),event_timestamp datetime);
create table staging_video_metrics(video_id int,channel_id int,metric_date date,views bigint,
likes bigint,comments bigint,shares int,watch_time_minutes bigint,subscribers_gained bigint);
create table staging_videos(video_id int primary key,channel_id bigint,video_title varchar(100),
category varchar(60),publish_date date);
# Viewing the data from the staging tables 
select * from staging_cleaned_channels;
select * from staging_cleaned_dates;
select * from staging_cleaned_traffic;
select * from staging_cleaned_videos_events;
select * from staging_video_metrics;
select * from staging_videos;









