# Section F- End to End Pipeline
create database dbpipes;
use dbpipes;
select * from channels;
select * from dates;
select * from videos;
select * from traffics;
select * from video_metrics;
select * from video_events;
select sum(likes)as Total_Likes,sum(views)as Total_Views 
from video_metrics;





