YOUTUBE ANALYTICS DATASET PACKAGE

Clean project inputs:
- videos.csv
- channels.csv
- video_metrics.csv
- traffic_sources.csv
- video_events.csv

Practice dirty inputs:
- videos_dirty.csv
- channels_dirty.csv
- video_metrics_dirty.csv
- traffic_sources_dirty.csv

Helper:
- dim_date.csv

Project mapping:
Q1-Q4: clean CSVs + dirty CSVs
Q5-Q10: videos + channels + video_metrics
Q11-Q15: dimensions/facts can be built from the CSVs
Q16-Q20: videos + channels + video_metrics
Q21-Q25: video_events.csv
Q26-Q30: all relevant clean datasets
